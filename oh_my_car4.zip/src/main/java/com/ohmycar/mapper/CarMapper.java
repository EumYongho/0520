package com.ohmycar.mapper;

import org.apache.ibatis.annotations.Mapper;
import com.ohmycar.domain.CarVO;

@Mapper
public interface CarMapper {
	CarVO getCarByCarId(String carId);

	void updateCar(CarVO carVO);
}
